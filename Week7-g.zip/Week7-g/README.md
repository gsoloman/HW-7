# JS-Pizza

## Update 21.05.2016
Відключено не потрібний JavaScript. https://github.com/seagullua/JS-Pizza/commit/4313efd27a23cab2890c38ece1b8cecd87faf4af
