/**
 * Created by chaika on 25.01.16.
 */

$(function(){
    //This code will execute when the page is ready
    var PizzaCart = require('./order/PizzaCart');
    var API = require("./API");
    var Form = require('./order/Form');
    var Maps = require('./order/Maps');

    PizzaCart.initialiseCart();
    Maps.initMap();
    Form.initForm();

    $("#next_button").click(function() {
        if (!Form.isEverythingCorrect())
            return; 

        $("#first_step").hide();
        var order_info = {
            name: $("#name").val().trim(),
            phone: $("#phone_e").val().trim(),
            address: $("#address").val().trim(),
            cart: PizzaCart.getPizzaInCart()
        };

        API.createOrder(order_info, function(err, result) {
            var items = JSON.parse(result);

            LiqPayCheckout.init({
                data: items.data,
                signature: items.signature,
                embedTo: "#liqpay",
                mode: "embed"
            }).on("liqpay.callback", function(paymentResult) {
                    if (paymentResult.status === "sandbox") {
                        PizzaCart.clear();
						$("#result_success").show();
                    }
                    else {
						$("#result_fail").show();
                    }
                 });
        });
        $("#second_step").show();
    });
});