var Form = require("./Form");

var map;
var destMarker;
var renderer;

function initMap() {
    var mapProp = {
        center: new google.maps.LatLng(50.464379, 30.519131),
        zoom: 11
    };
    var $map = document.getElementById("map");
	map = new google.maps.Map($map, mapProp);
	
    let marker = new google.maps.Marker({
        position: new google.maps.LatLng(50.464379, 30.519131),
        map: map,
        icon: "assets/images/map-icon.png"
	});
	
    google.maps.event.addListener(map, "click", function(me) {
        resetMap();
        var coordinates = me.latLng;
        geocodeLatLng(coordinates, function(err, address) {
            if (!err) {
                calculateRoute(coordinates, function(err, data) {
                    if (err) Form.addressWrong();
                    else {
                        destMarker = new google.maps.Marker({
                            position: coordinates,
                            map: map,
                            icon: "assets/images/home-icon.png"
                        });
                        drawRoute(data.route);
                        Form.addressCorrect(data.duration, address);
                    }
                });
            } else {
                Form.addressWrong();
            }
        });
    });
}

function resetMap() {
    if (destMarker) destMarker.setMap(null);
    if (renderer) renderer.setMap(null);
}

function geocodeLatLng(latlng, callback) {
    //Модуль за роботу з адресою
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({ location: latlng }, function(results, status) {
        if (status === google.maps.GeocoderStatus.OK && results[1]) {
            var adress = results[1].formatted_address;
            callback(null, adress);
        } else {
            callback(new Error("Can't	find	adress"));
        }
    });
}

function checkAddress(address) {
    resetMap();
    geocodeAddress(address, function(err, coords) {
        if (err) Form.addressWrong();
        else {
            calculateRoute(coords, function(err, data) {
                if (err) Form.addressWrong();
                else {
                    destMarker = new google.maps.Marker({
                        position: coords,
                        map: map,
                        icon: "assets/images/home-icon.png"
                    });
                    drawRoute(data.route);
                    Form.addressCorrect(data.duration);
                }
            });
        }
    });
}

function geocodeAddress(address, callback) {
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: address }, function(results, status) {
        if (status === google.maps.GeocoderStatus.OK && results[0]) {
            var coordinates = results[0].geometry.location;
            callback(null, coordinates);
        } else {
            callback(new Error("Can	not	find	the	adress"));
        }
    });
}

function calculateRoute(B_latlng, callback) {
    var directionService = new google.maps.DirectionsService();
    directionService.route(
        {
            origin: new google.maps.LatLng(50.464379, 30.519131),
            destination: B_latlng,
            travelMode: google.maps.TravelMode["DRIVING"]
        },
        function(response, status) {
            if (status == google.maps.DirectionsStatus.OK) {
                var leg = response.routes[0].legs[0];
                callback(null, {
                    route: response,
                    duration: leg.duration.text
                });
            } else {
                callback(new Error("Can'	not	find	direction"));
            }
        }
    );
}

function drawRoute(route) {
    renderer = new google.maps.DirectionsRenderer();
    renderer.setOptions({ suppressMarkers: true });
    renderer.setMap(map);
    renderer.setDirections(route);
}

exports.initMap = initMap;
exports.checkAddress = checkAddress;
exports.reset = resetMap;
