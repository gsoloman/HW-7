var Maps = require("./Maps");

function checkName() {
    var val = $("#name")
        .val()
        .trim();
    for (var i = 0; i < val.length; i++) {
        if (
            val.charAt(i).toUpperCase() === val.charAt(i).toLowerCase() &&
            val.charAt(i) !== " "
        ) {
            return false;
        }
    }
    if (val.length < 8) return false;
    return true;
}

function checkPhone() {
    var val = $("#phone_e")
        .val()
        .trim();
    for (var i = 0; i < val.length; i++) {
        if (
            (val.charAt(i) < "0" || val.charAt(i) > "9") &&
            val.charAt(i) !== "+"
        ) {
            return false;
        }
    }

    if (val.length === 13) {
        if (val.substring(0, 4) !== "+380") return false;
        return true;
    }

    if (val.length === 10) {
        if (val.charAt(0) !== "0") return false;
        return true;
    }
    return false;
}

function checkAddress() {
    var val = $("#address")
        .val()
        .trim();
    if (val.length < 10 || val.length > 100) addressWrong();
    Maps.checkAddress(val);
}

function addressWrong() {
    $("#info_duration").text("невідомий");
    $("#info_address").text("невідома");
    $("#address_l").addClass("error");
    $("#address").addClass("error");
    $("#address_err").removeClass("not_visible");
    Maps.reset();
}

function addressCorrect(duration, address) {
    $("#info_duration").text(duration);
    if (!address)
        address = $("#address")
            .val()
            .trim();
    else {
        $("#address").val(address);
    }
    $("#info_address").text(address);
    $("#address_l").removeClass("error");
    $("#address").removeClass("error");
    $("#address_err").addClass("not_visible");
}

function initForm() {
    $("#name").focusout(function() {
        if (checkName()) {
            $("#name_l").removeClass("error");
            $("#name").removeClass("error");
            $("#name_err").addClass("not_visible");
        } else {
            $("#name_l").addClass("error");
            $("#name").addClass("error");
            $("#name_err").removeClass("not_visible");
        }
    });
    $("#phone_e").focusout(function() {
        if (checkPhone()) {
            $("#phone_l").removeClass("error");
            $("#phone_e").removeClass("error");
            $("#phone_err").addClass("not_visible");
        } else {
            $("#phone_l").addClass("error");
            $("#phone_e").addClass("error");
            $("#phone_err").removeClass("not_visible");
        }
    });
    $("#address").focusout(function() {
        checkAddress();
    });
}

function isEverythingCorrect() {
    return (
        checkName() &&
        checkPhone() &&
        !$("#address").hasClass("error") &&
        $("#address").val().trim().length > 0
    );
}

exports.initForm = initForm;
exports.addressCorrect = addressCorrect;
exports.addressWrong = addressWrong;
exports.isEverythingCorrect = isEverythingCorrect;
