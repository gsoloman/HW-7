/**
 * Created by chaika on 09.02.16.
 */
var Pizza_List = require('./data/Pizza_List');
var crypto = require('crypto');

exports.getPizzaList = function(req, res) {
    res.send(Pizza_List);
};

exports.createOrder = function(req, res) {
    var order_info = req.body;
    
    function sha1(string) {
        var sha1 = crypto.createHash('sha1');
        sha1.update(string);
        return sha1.digest('base64');
    }

    function description(name, address, phone, cart) {
        var result = '';
        result = result + 'Замовлення піци: ' + name + '\n';
        result = result + 'Адреса доставки: ' + address + '\n';
        result = result + 'Телефон: ' + phone + '\n';
        result = result + 'Замовлення:\n';
        for (var i = 0; i < cart.length; i++) {
            result = result + '- ' + cart[i].quantity + 'шт. [' + cart[i].size + '] ' + cart[i].pizza.title + ';\n';
        }
        result = result + '\n' + 'Разом ' + price(cart) + ' грн.';
        return result;
    }

    function price(cart) {
        var result = 0;
        for (var i = 0; i < cart.length; i++) {
            result += cart[i].pizza[cart[i].size === 'Велика' ? 'big_size' : 'small_size'].price * cart[i].quantity;
        }
        return result;
    }

    var order = {
        version: 3,
        public_key: 'sandbox_i6216786729', // public key
        action: 'pay',
        amount: price(order_info.cart),
        currency: 'UAH',
        description: description(order_info.name, order_info.address, order_info.phone, order_info.cart),
        order_id: Math.random(),
        sandbox: 1
    };

    var order_base64 = new Buffer(JSON.stringify(order)).toString('base64');
    var result = JSON.stringify({
        data: order_base64,
        signature: sha1('sandbox_vDuCAvWocq8v8WlODaQBxyOaAM3GHbiTdIPV9IwN' + order_base64 + 'sandbox_vDuCAvWocq8v8WlODaQBxyOaAM3GHbiTdIPV9IwN') // private key
    });
    res.send(result);
};